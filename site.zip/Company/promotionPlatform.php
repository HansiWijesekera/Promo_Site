<?php

include '../Headers/companyHeader.php';
error_reporting(0);

$companyId = $_SESSION['companyId'];
?>

<!DOCTYPE html>
<html>

</head>

<body>

    <div class="container-fluid" style="margin-top:30px !important;">
        <div class="container">
            <div class="row 2">
                <div class="col-8">
                    <h1>Current Promotions</h1><br>
                </div>
                <div class="col-4" style="text-align: right;">
                    <a href="../index.php" class="btn btn-primary btn-sm">Go Back</a>
                    <a href="newPromotion.php" class="btn btn-primary btn-sm">Add New</a><br><br>
                </div>
            </div>
            <div class="table-responsive">
                <table id="tblUser">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Photo</th>
                            <th>Link</th>
                            <th>Added Date</th>
                            <th>Expired Date</th>
                            <th>Sub Categories</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $selectQuery = "select * from promotions inner join company on company.companyId = promotions.companyId where promotions.expireDate > CURDATE() and promotions.companyId  = $companyId";
                        $squery = mysqli_query($con, $selectQuery);
                        while (($result = mysqli_fetch_assoc($squery))) {
                            $categoryID = $result['categoryId'];
                        ?>
                            <tr>
                                <td><?php echo $result['title']; ?></td>
                                <td>
                                    <img src="<?php echo '../Promotions/' . basename($result['photo']); ?>" style="width: 150px; height: 100px;" onclick="window.open(this.src)" />
                                </td>
                                <td><?php echo $result['link']; ?></td>
                                <td><?php echo $result['addedDate']; ?></td>
                                <td><?php echo $result['expireDate']; ?></td>
                                <td>
                                    <?php
                                    //$promoId = $result['promoId'];
                                    //$selectQuery = "select description from promo_subcategories inner join subcategory on  promo_subcategories.subcatId = subcategory.subCatId where promo_subcategories.promoId = $promoId";
                                    // $squery = mysqli_query($con, $selectQuery);
                                    // $result1 = mysqli_fetch_row($squery);
                                    // echo $result1[0];
                                    ?>
                                </td>
                                <td>
                                    <a href="editPromotion.php?id=<?php echo $result['promoId']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"></i></a>
                                    <a href="expirePromotion.php?id=<?php echo $result['promoId']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>

            </div>


        </div>
    </div>

</body>