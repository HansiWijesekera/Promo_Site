<?php
include '../Headers/companyHeader.php';
$companyId = $_SESSION['companyId'];

if (isset($_POST['title'])) {
    $title = $_POST['title'];
    //$photo = $_POST['photo'];
    $link = $_POST['link'];
    $expireDate = $_POST['expireDate'];
    //$subcategory = $_POST['subcategory'];

    $query1 = "INSERT INTO promotions (companyId,title,photo,link,addedDate,expireDate)
            VALUES('$companyId','$title','','$link', CURDATE() ,'$expireDate')";
    if (mysqli_query($con, $query1)) {
        $promoID = mysqli_insert_id($con);
        $currentDirectory = getcwd();
        $targetDir = "/../Promotions/";
        $fileName = preg_replace('/\s+/', '_', $promoID . '_' . $_FILES['picture']['name']);
        $fileTmpName  = $_FILES['picture']['tmp_name'];
        //$targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        $uploadPath = $currentDirectory . $targetDir . basename($fileName);
        move_uploaded_file($fileTmpName, $uploadPath);

        $query1 = "UPDATE promotions set  photo='" . $fileName . "' WHERE promoId=  $promoID ";
        if (mysqli_query($con, $query1)) {
            echo " <script type='text/javascript'>alert('Promotion Added Succesfully');location.href='promotionPlatform.php'</script>";
        } else {
            echo " <script type='text/javascript'>alert('Error In Promotion Details');location.href='newPromotion.php'</script>";
        }
    }
}

?>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="ajax-script.js"></script>

</head>

<div class="row d-flex justify-content-center">
    <div class="col-lg-7" style="padding: 10%;">
        <div class="card">
            <div class="card-header text-center">
                <h4>Add New Promotion</h4>
            </div>

            <form method="post" enctype="multipart/form-data">
                <div class="form-input py-2" style="padding-left: 20px;  border-radius: 5px;background-color: #f2f2f2;padding: 20px;">
                    <div class="form-group">
                        <label class="form-control-label">Enter Title</label>
                        <input type="text" name="title" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Enter Picture</label>
                        <input type="file" name="picture" class="form-control" accept="image/jpg, image/jpeg, image/png, image/tif " id="someId" required />
                        <script>
                            var file = document.getElementById('someId');

                            file.onchange = function(e) {
                                var ext = this.value.match(/\.([^\.]+)$/)[1];
                                switch (ext) {
                                    case 'jpg':
                                    case 'jpeg':
                                    case 'png':
                                    case 'tif':
                                        break;
                                    default:
                                        alert('Not allowed file type please add JPEG,JPG or PNG file');
                                        this.value = '';
                                }
                            };
                        </script>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Enter Link</label>
                        <input type="text" name="link" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Enter Expire Date</label>
                        <input type="date" name="expireDate" class="form-control" min="<?= date('Y-m-d'); ?>" required />
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-sm" name="submit" value="Add Promotion">
                    </div>

                </div>
            </form>

        </div>
    </div>
</div>