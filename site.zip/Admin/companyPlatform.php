<?php

include '../Headers/adminHeader.php';
error_reporting(0);

if (isset($_POST['submit'])) {
    $_SESSION['categoryName'] = $_POST['categoryName'];
    // $companyID = $result1[0];

}
$categoryName = $_SESSION['categoryName'];

$selectQuery1 = "select categoryId from categories where categoryName = '$categoryName' ";
$squery1  = mysqli_query($con, $selectQuery1);
while (($result1 = mysqli_fetch_assoc($squery1))) {
    $categoryId = implode(array_slice($result1, 0));
}
$_SESSION['categoryId'] = $categoryId;
?>

<!DOCTYPE html>
<html>


</head>

<body>

    <div class="container-fluid" style="margin-top:30px !important;">
        <div class="container">
            <div class="row 2">
                <div class="col-8">
                    <h1>Registerd Companies - <?php echo $categoryName; ?></h1><br>
                </div>
                <div class="col-4" style="text-align: right;">
                    <a href="../index.php" class="btn btn-primary btn-sm">Go Back</a>
                    <a href="newCompany.php" class="btn btn-primary btn-sm">Add New</a><br><br>
                </div>
            </div>
            <form method="post">
                <label class="form-control-label">Please Select Category</label>
                <div>
                    <?php
                    $queryX = "SELECT * FROM categories where status = 'A'";
                    $result = $con->query($queryX);
                    if (!empty($result) && $result->num_rows > 0) {
                        $options = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    }
                    ?>
                    <select name="categoryName" required>
                        <option>Select</option>
                        <?php
                        foreach ($options as $option) {
                        ?>
                            <option><?php echo $option['categoryName']; ?> </option>
                        <?php
                        }
                        ?>
                    </select>
                    <input type="submit" class="btn btn-primary btn-sm" name="submit" value="Submit">
                </div><br>

            </form>

            <div class="table-responsive">
                <table id="tblUser">
                    <thead>
                        <tr>
                            <th>Avatar</th>
                            <th>Company Id</th>
                            <th>Comapany Name</th>
                            <th>Address</th>
                            <th>Contact Number</th>
                            <th>Web Site</th>
                            <th>Email</th>
                            <th>Registerd Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $selectQuery = "select * from company where company.status = 'A' and categoryId = $categoryId";
                        $squery = mysqli_query($con, $selectQuery);
                        while (($result = mysqli_fetch_assoc($squery))) {
                        ?>
                            <tr>
                                <td>
                                    <img src="<?php echo '../Company/Picture/' . basename($result['picture']); ?>" style="width: 45px; height: 45px;  border-radius: 50%;" onclick="window.open(this.src)" />
                                </td>
                                <td><?php echo $result['companyId'];
                                    $companyId = $result['companyId'] ?></td>
                                <td><?php echo $result['companyName']; ?></td>
                                <td><?php echo $result['address']; ?></td>
                                <td><?php echo $result['contactNumber']; ?></td>
                                <td><?php echo $result['website']; ?></td>
                                <td><?php echo $result['email']; ?></td>
                                <td><?php echo $result['registeredDate']; ?></td>
                                <td>
                                    <a href="editCompany.php?id=<?php echo $result['companyId']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"></i></a>
                                    <a href="expireCompany.php?id=<?php echo $result['companyId']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                    <a href="newpromotion.php?id=<?php echo $result['companyId']; ?>" class="btn btn-warning btn-sm"><i class="fa fa-cloud-upload"></i></a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>

            </div>


        </div>
    </div>

</body>