<?php
include '../Headers/adminHeader.php';

$id = $_GET['id'];

$query = "update categories set status = 'E' where categoryId = $id ";
if (mysqli_query($con, $query)) {
    echo " <script type='text/javascript'>alert(' Expired Sucessfully');location.href='categories.php'</script>";
}
