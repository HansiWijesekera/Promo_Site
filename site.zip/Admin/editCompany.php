<?php
include '../Headers/adminHeader.php';
$id = $_GET['id'];

?>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="ajax-script.js"></script>
</head>

<div class="row d-flex justify-content-center">
    <div class="col-lg-7" style="padding: 10%;">
        <div class="card">
            <div class="card-header text-center">
                <h4>Change Company Datails</h4>
            </div>

            <form method="post" enctype="multipart/form-data">
                <div class="form-input py-2" style="padding-left: 20px;  border-radius: 5px;background-color: #f2f2f2;padding: 20px;">
                    <?php
                    $selectQuery = "SELECT * FROM company WHERE companyId= $id ";
                    $squery = mysqli_query($con, $selectQuery);

                    while (($result = mysqli_fetch_assoc($squery))) {

                        if (isset($_POST['companyName'])) {
                            $companyName = $_POST['companyName'];
                            $address = $_POST['address'];
                            $contactNumber = $_POST['contactNumber'];
                            $website = $_POST['website'];
                            $email = $_POST['email'];

                            if ($_FILES['picture']['size'] == 0) {
                                $fileName = ($result['picture']);
                            } else {
                                $currentDirectory = getcwd();
                                $targetDir = "/../Company/Picture/";
                                $fileName = preg_replace('/\s+/', '_', $companyName . '_' . $_FILES['picture']['name']);
                                $fileTmpName  = $_FILES['picture']['tmp_name'];
                                //$targetFilePath = $targetDir . $fileName;
                                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                                $uploadPath = $currentDirectory . $targetDir . basename($fileName);
                                move_uploaded_file($fileTmpName, $uploadPath);
                            }


                            $query =
                                "UPDATE company set companyName='" . $companyName . "', address='" . $address . "', 
                               contactNumber='" . $contactNumber . "', picture='" . $fileName . "' , website='" . $website . "', email='" . $email . "' WHERE companyId= $id ";
                            // if (count($_POST) > 0) {
                            //    mysqli_query($con, "UPDATE employee set companyName='" . $companyName . "', salaryDate='" . $salaryDate . "', 
                            //    BRI='" . $BRI . "', status='" . $status . "' WHERE userId = 13");
                            //    $message = "Record Modified Successfully";
                            //   }
                            if (count($_POST) > 0) {
                                if (mysqli_query($con, $query)) {
                                    echo " <script type='text/javascript'>alert('User Details Modified Sucessfully');location.href='companyPlatform.php'</script>";
                                } else {
                                    echo "Error" . $query . "<br>" . mysqli_error($con);
                                }
                            }
                            mysqli_close($con);
                        }

                    ?>
                        <div class="form-group">
                            <label class="form-control-label">Enter company Name</label>
                            <input type="text" name="companyName" class="form-control" value="<?php echo $result['companyName']; ?>" required />
                        </div>
                        <div class="form-group">
                            <label class="form-control-label">Enter Address</label>
                            <input type="text" name="address" class="form-control" value="<?php echo $result['address']; ?>" required />
                        </div>
                        <div class="form-group">
                            <label class="form-control-label">Enter contact Number</label>
                            <input type="text" name="contactNumber" class="form-control" value="<?php echo $result['contactNumber']; ?>" required />
                        </div>

                        <div class="form-group">
                            <label class="form-control-label">Upload Photo</label>
                            <input type="file" name="picture" size="20" accept="image/jpg, image/jpeg, image/png, image/tif " id="someId" />
                            <script>
                                var file = document.getElementById('someId');

                                file.onchange = function(e) {
                                    var ext = this.value.match(/\.([^\.]+)$/)[1];
                                    switch (ext) {
                                        case 'jpg':
                                        case 'jpeg':
                                        case 'png':
                                        case 'tif':
                                            break;
                                        default:
                                            alert('Not allowed file type please add JPEG,JPG or PNG file');
                                            this.value = '';
                                    }
                                };
                            </script>
                        </div>
                        <img src="<?php echo '../Company/Picture/' . basename($result['picture']); ?>" style="width: 45px; height: 45px;" />
                        <div class="form-group">
                            <label class="form-control-label">Enter Website</label>
                            <input type="text" name="website" class="form-control" value="<?php echo $result['website']; ?>" required />
                        </div>
                        <div class="form-group">
                            <label class="form-control-label">Enter Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $result['email']; ?>" required />
                        </div>
                        <div class="form-group">
                            <label class="form-control-label">Select Status</label>
                            <select id="status" name="status" class="form-control" value="<?php echo $result['status']; ?>">
                                <option value="A">Active</option>
                                <option value="E">Expired</option>
                                <option value="I">Initiated</option>
                            </select>
                        </div>

                    <?php
                    }
                    ?>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-sm" name="submit" value="Update Details">
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>