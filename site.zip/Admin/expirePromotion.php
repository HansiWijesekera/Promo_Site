<?php
include '../Headers/adminHeader.php';

$id = $_GET['id'];

$selectQuery = "SELECT * FROM promotions WHERE promoId = $id";
$squery = mysqli_query($con, $selectQuery);

$query = "update promotions set expireDate = CURDATE() where promoId = $id ";
if (mysqli_query($con, $query)) {
    echo " <script type='text/javascript'>alert('Promotion Expired Sucessfully');location.href='promotionPlatform.php'</script>";
}