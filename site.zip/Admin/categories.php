<?php
include '../Headers/adminHeader.php';

if (isset($_POST['submit'])) {
    $categoryName = $_POST['categoryName'];
    $sql1 = "SELECT * FROM categories WHERE categoryName='$categoryName' and status = 'A'";
    $res1 = mysqli_query($con, $sql1);

    $query =
        "INSERT INTO categories(categoryName,status)
	     VALUES('$categoryName','A')";

    if (mysqli_num_rows($res1) > 0) {
        echo "<script type='text/javascript'>alert('Existing Category!');location.href='categories.php'</script>";
    } else {
        $query = mysqli_query($con, $query);
        $userId = mysqli_insert_id($con);
        echo "<script type='text/javascript'>alert('Code Added Sucessfully');location.href='categories.php'</script>";
    }
}
?>

<body>
    <div class="container-fluid">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-7" style="padding: 10%;">
                    <div class="card">
                        <div class="card-header text-center">
                            <h4>Add Category</h4>
                        </div>
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-input py-2" style="padding-left: 20px;  border-radius: 5px;background-color: #f2f2f2;padding: 20px;">
                                <div class="form-group">
                                    <label class="form-control-label">Enter category Name</label>
                                    <input type="text" name="categoryName" class="form-control" required />
                                </div>
                                <br>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-sm" name="submit" value="Add Category">
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-md-9">
                    <h1>Current Categories</h1>
                </div>
            </div>
            <div class="table-responsive">
                <table id="tblUser">
                    <thead>
                        <tr>
                            <th>Category Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $selectQuery = "select * from categories where status = 'A'";
                        $squery = mysqli_query($con, $selectQuery);
                        while (($result = mysqli_fetch_assoc($squery))) {
                        ?>
                            <tr>
                                <td><?php echo $result['categoryName']; ?></td>
                                <td><?php echo $result['status']; ?></td>
                                <td>
                                    <a href="expireCategory.php?id=<?php echo $result['categoryId']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>



</body>