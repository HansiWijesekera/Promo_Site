<?php
include '../Headers/adminHeader.php';
$id = $_GET['id'];

?>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="ajax-script.js"></script>
</head>

<div class="row d-flex justify-content-center">
    <div class="col-lg-7" style="padding: 10%;">
        <div class="card">
            <div class="card-header text-center">
                <h4>Change Promotion Datails</h4>
            </div>

            <form method="post" enctype="multipart/form-data">
                <div class="form-input py-2" style="padding-left: 20px;  border-radius: 5px;background-color: #f2f2f2;padding: 20px;">
                    <?php
                    $selectQuery = "SELECT * FROM promotions WHERE promoId= $id ";
                    $squery = mysqli_query($con, $selectQuery);

                    while (($result = mysqli_fetch_assoc($squery))) {

                        if (isset($_POST['title'])) {
                            $title = $_POST['title'];
                            // $photo = $_POST['photo'];
                            $link = $_POST['link'];
                            $expireDate = $_POST['expireDate'];

                            if ($_FILES['picture']['size'] == 0) {
                                $fileName = ($result['photo']);
                            } else {
                                $currentDirectory = getcwd();
                                $targetDir = "/../Promotions/";
                                $fileName = preg_replace('/\s+/', '_', $id . '_' . $_FILES['picture']['name']);
                                $fileTmpName  = $_FILES['picture']['tmp_name'];
                                //$targetFilePath = $targetDir . $fileName;
                                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                                $uploadPath = $currentDirectory . $targetDir . basename($fileName);
                                move_uploaded_file($fileTmpName, $uploadPath);
                            }

                            $query =
                                "UPDATE promotions set title='" . $title . "', photo='" . $fileName . "', 
                               link='" . $link . "', expireDate='" . $expireDate . "' WHERE promoId= $id ";
                            // if (count($_POST) > 0) {
                            //    mysqli_query($con, "UPDATE employee set companyName='" . $companyName . "', salaryDate='" . $salaryDate . "', 
                            //    BRI='" . $BRI . "', status='" . $status . "' WHERE userId = 13");
                            //    $message = "Record Modified Successfully";
                            //   }
                            if (count($_POST) > 0) {
                                if (mysqli_query($con, $query)) {
                                    echo " <script type='text/javascript'>alert('Promotion Details Modified Sucessfully');location.href='promotionPlatform.php'</script>";
                                } else {
                                    echo "Error" . $query . "<br>" . mysqli_error($con);
                                }
                            }
                            mysqli_close($con);
                        }

                    ?>
                        <div class="form-group">
                            <label class="form-control-label">Enter Title</label>
                            <input type="text" name="title" class="form-control" value="<?php echo $result['title']; ?>" required />
                        </div>
                        <div class="form-group">
                            <label class="form-control-label">Upload Photo</label>
                            <input type="file" name="picture" size="20" accept="image/jpg, image/jpeg, image/png, image/tif " id="someId" />
                            <script>
                                var file = document.getElementById('someId');

                                file.onchange = function(e) {
                                    var ext = this.value.match(/\.([^\.]+)$/)[1];
                                    switch (ext) {
                                        case 'jpg':
                                        case 'jpeg':
                                        case 'png':
                                        case 'tif':
                                            break;
                                        default:
                                            alert('Not allowed file type please add JPEG,JPG or PNG file');
                                            this.value = '';
                                    }
                                };
                            </script>
                        </div>
                        <img src="<?php echo '../Promotions/' . basename($result['photo']); ?>" style="width: 65px; height: 45px;" />
                        <div class="form-group">
                            <label class="form-control-label">Enter Link</label>
                            <input type="text" name="link" class="form-control" value="<?php echo $result['link']; ?>" required />
                        </div>
                        <div class="form-group">
                            <label class="form-control-label">Enter Expire Date</label>
                            <input type="date" name="expireDate" class="form-control" value="<?php echo $result['expireDate']; ?>" min="<?= date('Y-m-d'); ?>" required />
                        </div>
                    <?php
                    }
                    ?>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-sm" name="submit" value="Update Details">
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>